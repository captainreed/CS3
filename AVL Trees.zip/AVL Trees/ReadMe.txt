the changes to this software were made by Brandon Reed
in this version all of the steps from part one of the assignment are complete.
the output from the brute force method works correctly. the AVL tree output still needs work.
