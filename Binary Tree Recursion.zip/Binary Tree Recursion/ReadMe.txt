this program was completed by Brandon Reed. 

This Current version only has the first 7 functions working. make sure that you 
comment out the program right above the folowwing line
int perfectBalanceI[] = { 2,5,7,9,12,14,15,16,21,56,69,80,82,83,84,74,90,95,99 };