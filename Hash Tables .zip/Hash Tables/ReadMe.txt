program written by Brandon Reed.

the computer does not know the about which type of words follow others 
for example adjectives come before nouns etc. if the computer knew that
that a sentance typically includes a subject, adjective, verb it could assemble
a better sentance.also if the computer knew how to identify what the function of
the word given the context then it could make a decision based on the previous 
information i have included it might be able to make a better poem.

certain parts of the longer poems seemed to make sense, i believe this is because
there is a higher probability that words will arange themselves into correct order
on accident.